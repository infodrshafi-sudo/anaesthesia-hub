Anaesthesia Hub Android WebView fix — version 1.1

This replacement upload keeps the existing six-tile dashboard unchanged.
It updates only the Android wrapper to support:
- Native Android sharing for files/images passed through navigator.share().
- JavaScript Blob URL downloads saved to the Android Downloads folder.
- Existing HTTPS downloads and file uploads remain supported.

Upload this ZIP's contents as the replacement repository file named anaesthesia-hub-upload.zip.
The existing GitHub Actions workflow watches that filename and will build APK version 1.1 (versionCode 2).
After a successful run, download the anaesthesia-hub-apk artifact and install app-debug.apk over the current app.

The OT Planner and other linked websites are not modified. The planned dashboard tile changes are not included.
