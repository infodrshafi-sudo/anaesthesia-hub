ANAESTHESIA HUB — DIRECT ZIP UPLOAD
===================================

You do NOT need to extract the ZIP on your Android phone.

FILES
-----
1. anaesthesia-hub-upload.zip
   Upload this one ZIP file directly to the root of your GitHub repository.

2. Anaesthesia_Hub_GitHub_Workflow.yml
   GitHub needs this workflow file installed ONCE at:
   .github/workflows/build.yml

ONE-TIME GITHUB SETUP
---------------------
A. Create a new PUBLIC repository named anaesthesia-hub.

B. In the repository, use Add file > Create new file.
   In the filename box enter exactly:
   .github/workflows/build.yml

C. Open Anaesthesia_Hub_GitHub_Workflow.yml from this download, copy all its
   contents, paste them into the GitHub editor, and commit the new file to main.
   This first commit only installs the automation; it will not try to build yet.

D. Open repository Settings > Pages.
   Under Build and deployment, set Source to GitHub Actions.

E. Upload anaesthesia-hub-upload.zip directly to the ROOT of the repository:
   Add file > Upload files > select anaesthesia-hub-upload.zip > Commit changes.

AFTER THAT
----------
The ZIP upload starts GitHub Actions automatically.
GitHub will:
1. Extract the uploaded ZIP on its server.
2. Extract the website and Android project inside it.
3. Build the Android debug APK.
4. Publish the website to GitHub Pages.
5. Save the APK as an Actions artifact named anaesthesia-hub-apk.

WEB ADDRESS
-----------
https://YOUR-GITHUB-USERNAME.github.io/anaesthesia-hub/

DOWNLOAD THE APK
----------------
Repository > Actions > latest successful "Build Anaesthesia Hub" run
> Artifacts > anaesthesia-hub-apk.
Download the artifact ZIP, extract it on Android, and install app-debug.apk.

IMPORTANT
---------
- Upload anaesthesia-hub-upload.zip at the repository root; do not put it in a folder.
- The workflow file must be installed once at .github/workflows/build.yml.
  GitHub does not execute a workflow merely because it is inside an uploaded ZIP.
- The APK artifact is a debug build for personal testing, not a Play Store release.
- APK artifacts are retained for 30 days; upload the same ZIP again or run the
  workflow manually to generate another APK.
- Internet is required to use the six linked websites.
- Do not enter real patient-identifiable information into linked systems unless
  those systems are independently approved and secured for clinical use.
- PAC and Anesthesia Suite remain separate dashboard destinations.
